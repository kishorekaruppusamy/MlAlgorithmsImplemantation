import pickle

def load_model():
    """
        Loading the model
        Args:
            model_path : should be the full path with .whl extension
    """
    
    with open("linear_model.pkl", 'rb') as file:
        model = pickle.load(file)
        
    return model
    
    
def predict(model, test_data):
    
    """
        predict the output for given data using given pre trained model
    """
        
    y_pred = model.predict(test_data)
    
    return y_pred